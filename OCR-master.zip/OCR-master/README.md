# OCR, Python GUI for OCR, Linear equation solver using Python 

Linear Equation solver using python gui
